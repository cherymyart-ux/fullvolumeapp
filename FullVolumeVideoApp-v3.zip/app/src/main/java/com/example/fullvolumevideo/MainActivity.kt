package com.example.fullvolumevideo

import android.app.Activity
import android.content.Context
import android.database.ContentObserver
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.VideoView

class MainActivity : Activity() {

    private lateinit var audioManager: AudioManager
    private lateinit var videoView: VideoView
    private val handler = Handler(Looper.getMainLooper())
    private var maxVolume: Int = 15

    // Keeps the media volume pinned to max while the app is in the foreground.
    private val volumeEnforcer = object : Runnable {
        override fun run() {
            setMaxMediaVolume()
            handler.postDelayed(this, 100)
        }
    }

    private val volumeObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            super.onChange(selfChange)
            setMaxMediaVolume()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUI()

        setContentView(R.layout.activity_main)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        setMaxMediaVolume()

        contentResolver.registerContentObserver(
            Settings.System.CONTENT_URI,
            true,
            volumeObserver
        )

        videoView = findViewById(R.id.videoView)
        val uri = Uri.parse("android.resource://$packageName/${R.raw.video_1}")
        videoView.setVideoURI(uri)

        videoView.setOnPreparedListener { mp ->
            mp.isLooping = true
            mp.setVolume(1.0f, 1.0f)
            setMaxMediaVolume()
            videoView.start()
        }

        videoView.setOnCompletionListener {
            videoView.start()
        }
    }

    private fun setMaxMediaVolume() {
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (current < maxVolume) {
            audioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                maxVolume,
                0
            )
        }
    }

    private fun hideSystemUI() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemUI()
            setMaxMediaVolume()
        }
    }

    // Volume buttons still just re-assert max volume instead of lowering it.
    // Remove this override if you'd rather the volume buttons work normally.
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            event.keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            event.keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            setMaxMediaVolume()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    // Back button works normally now -- no override, so the activity just closes.

    override fun onResume() {
        super.onResume()
        hideSystemUI()
        setMaxMediaVolume()
        handler.post(volumeEnforcer)
        if (!videoView.isPlaying) {
            videoView.start()
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(volumeEnforcer)
    }

    override fun onDestroy() {
        contentResolver.unregisterContentObserver(volumeObserver)
        handler.removeCallbacks(volumeEnforcer)
        super.onDestroy()
    }
}
