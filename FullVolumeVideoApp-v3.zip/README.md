# FullVolumeVideoApp

Full-screen video player that keeps media volume pinned to maximum while playing.
Video file bundled at `app/src/main/res/raw/video_1.mp4`.

Compared to a "lock the user in" version, this one:
- Exits normally on back press / closing the app (no auto-relaunch).
- Does not request SYSTEM_ALERT_WINDOW.
- Still re-asserts max volume continuously and on volume-button presses while running.

Build with `gradle assembleDebug`, or push to GitHub for the included Actions workflow to build the APK.
